/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Imam
 */
public class Node2P {
    int data;
    Node2P next;
    Node2P prev;

    public Node2P(int data) {
        this.data = data;
        next = prev = null;
    }
    
}
