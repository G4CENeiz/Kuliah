<!DOCTYPE html>
<html>
<head>
    <title>Unggah Multiupload Gambar</title>
</head>
<body>
    <form id="upload-form" action="upload_ajax3.2.php" method="post" enctype="multipart/form-data">
        <input type="file" name="files[]" id="files" multiple="multiple">
        <input type="submit" name="submit" value="Unggah Gambar">
    </form>
    <div id="status"></div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="upload.js"></script>
</body>

</html>