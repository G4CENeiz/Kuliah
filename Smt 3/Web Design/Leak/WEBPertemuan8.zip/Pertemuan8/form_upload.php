<!DOCTYPE html>
<html>
<head>
    <title>File Uploud</title>
</head>
    <body>
        <form action="upload1.3.php" method="post" enctype="multipart/form-data">
            <input type="file" name="fileToUpload" id="fileToUpload"> 
            <input type="submit" value="Uploud File" name="submit">
        </form>
    </body>
</html>