<?php 
$servername = "localhost"; 
$username = "root";
$password = "";
$database = "prakwebdb";

$conn = mysqli_connect($servername,$username,$password,$database);
?>
