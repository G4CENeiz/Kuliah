<?php 
    echo $_COOKIE['user'];
?>