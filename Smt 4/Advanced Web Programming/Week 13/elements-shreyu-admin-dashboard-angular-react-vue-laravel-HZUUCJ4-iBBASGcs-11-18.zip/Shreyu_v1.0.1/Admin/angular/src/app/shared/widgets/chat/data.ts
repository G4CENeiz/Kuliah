const chatData = [
    {
        image: 'assets/images/users/avatar-9.jpg',
        name: 'Greeva',
        message: 'Hello!',
        time: '10:00'
    },
    {
        image: 'assets/images/users/avatar-7.jpg',
        name: 'Shreyu',
        message: 'Hi, How are you? What about our next meeting?',
        time: '10:01'
    },
    {
        image: 'assets/images/users/avatar-9.jpg',
        name: 'Greeva',
        message: 'Yeah everything is fine',
        time: '10:01'
    },
    {
        image: 'assets/images/users/avatar-7.jpg',
        name: 'Shreyu',
        message: 'Awesome! let me know if we can talk in 20 min',
        time: '10:02'
    }
];

export { chatData };
