// Chat data
export interface Chat {
    image: string;
    name: string;
    message: string;
    time: string;
}
