const colors = [
    {
        color: 'primary'
    },
    {
        color: 'secondary'
    },
    {
        color: 'success'
    },
    {
        color: 'danger'
    },
    {
        color: 'warning'
    },
    {
        color: 'info'
    },
    {
        color: 'dark'
    },
];

export { colors };
