export interface Price {
    pack: string;
    icon: string;
    price: string;
    storage: number;
    bandwidth: string;
    domain: string;
}
