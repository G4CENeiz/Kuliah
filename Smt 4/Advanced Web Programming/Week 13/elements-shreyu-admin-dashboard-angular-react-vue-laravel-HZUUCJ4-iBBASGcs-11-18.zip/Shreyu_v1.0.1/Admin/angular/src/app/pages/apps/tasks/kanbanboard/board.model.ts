// Kanban Board Data
export interface Task {
    title: string;
    date: string;
    task: string;
    user: string;
    comments: number;
    donetask: string;
    status: string;
}
