export interface Email {
    title: string;
    star?: boolean;
    subject: string;
    date: string;
    status: string;
}
