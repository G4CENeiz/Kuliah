export interface Tasks {
    id: string;
    name: string;
    user: string;
    time: string;
    task: string;
    message: number;
    status: string;
}
